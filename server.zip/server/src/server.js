require("dotenv").config();
const express = require("express");
const cors = require("cors");

const connectDB = require("./config/db");

const app = express();
app.use(cors());
app.use(express.json());

connectDB();

app.use("/", require("./routes/auth"));
app.use("/trips", require("./routes/trips"));
app.use("/stats", require("./routes/stats"));

app.listen(process.env.PORT, () => console.log("Server running"));