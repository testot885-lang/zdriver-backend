const router = require("express").Router();
const Trip = require("../models/Trip");

router.post("/", async (req, res) => {
  const { earnings, fuel } = req.body;
  const profit = earnings - fuel;
  const trip = await Trip.create({ earnings, fuel, profit });
  res.json(trip);
});

module.exports = router;