const router = require("express").Router();
const Trip = require("../models/Trip");

router.get("/", async (req, res) => {
  const trips = await Trip.find();
  const total = trips.reduce((a, t) => a + t.profit, 0);
  res.json({ total });
});

module.exports = router;