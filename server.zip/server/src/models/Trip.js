const mongoose = require("mongoose");

module.exports = mongoose.model("Trip", {
  earnings: Number,
  fuel: Number,
  profit: Number
});